# ------------------------------------------------Hospital Operations Performance & Patient Flow Analytics------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# 1. How do doctors rank within their departments based on patient visits?
WITH doctor_visits AS (
SELECT
d.department,
d.doctor_id,
d.doctor_name,
COUNT(a.visit_id) AS total_visits
FROM doctors d
JOIN appointments a
ON d.doctor_id = a.doctor_id
GROUP BY
d.department,
d.doctor_id,
d.doctor_name
)
SELECT
department,
doctor_id,
doctor_name,
total_visits,
DENSE_RANK() OVER (PARTITION BY department ORDER BY total_visits DESC) AS department_rank
FROM doctor_visits
ORDER BY department, department_rank;
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# Which doctors fall into the top revenue group compared to others?
WITH doctor_revenue AS (
SELECT
d.doctor_id,
d.doctor_name,
d.department,
round(SUM(a.consultation_fee + a.treatment_cost),2) AS total_revenue
FROM doctors d
JOIN appointments a
ON d.doctor_id = a.doctor_id
GROUP BY
d.doctor_id,
d.doctor_name,
d.department
),
revenue_groups AS (
SELECT
doctor_id,
doctor_name,
department,
total_revenue,
NTILE(4) OVER (ORDER BY total_revenue DESC) AS revenue_group
FROM doctor_revenue
)
SELECT
doctor_id,
doctor_name,
department,
total_revenue,
CASE
   WHEN REVENUE_GROUP = 1 THEN "TOP 25%"
   WHEN REVENUE_GROUP = 2 THEN "TOP 50%"
   WHEN REVENUE_GROUP IN (3,4) THEN "BELOW 50%"
   END AS REVENUE_SEGMENT
FROM revenue_groups
WHERE revenue_group = 1
ORDER BY total_revenue DESC;
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# 3. How has patient visit count changed compared to the previous time period?
WITH monthly_visits AS (
SELECT
DATE_FORMAT(visit_date, '%Y-%m') AS visit_month,
COUNT(*) AS visit_count
FROM appointments
GROUP BY DATE_FORMAT(visit_date, '%Y-%m')
),
visit_change AS (
SELECT
visit_month,
visit_count,
COALESCE(LAG(visit_count) OVER ( ORDER BY visit_month),"-") AS previous_visit_count
FROM monthly_visits
)
SELECT
visit_month,
visit_count,
previous_visit_count,
COALESCE((visit_count - previous_visit_count),"-") AS visit_change
FROM visit_change
ORDER BY visit_month;
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# How does the total number of patient visits accumulate over time?
WITH daily_visits AS (
SELECT
visit_date,
COUNT(*) AS visit_count
FROM appointments
GROUP BY visit_date
)
SELECT
visit_date,
visit_count,
SUM(visit_count) OVER (ORDER BY visit_date ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS cumulative_visits
FROM daily_visits
ORDER BY visit_date;
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# 5. How can doctors be grouped into workload buckets from lowest to highest?
WITH doctor_workload AS (
SELECT
d.doctor_id, d.doctor_name, d.department,
COUNT(a.visit_id) AS total_visits
FROM doctors d
JOIN appointments a ON d.doctor_id = a.doctor_id
GROUP BY d.doctor_id,d.doctor_name, d.department
),
workload_ntile AS (
SELECT
doctor_id, doctor_name, department, total_visits,
NTILE(3) OVER ( ORDER BY total_visits) AS workload_group
FROM doctor_workload
)
SELECT
doctor_id, doctor_name, department, total_visits,
CASE
	WHEN workload_group = 1 THEN 'Low'
	WHEN workload_group = 2 THEN 'Medium'
	WHEN workload_group = 3 THEN 'High'
    END AS workload_bucket
FROM workload_ntile
ORDER BY total_visits desc;
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# How many days usually pass between a patient’s consecutive visits, show by most frequent visit.
WITH patient_visits AS (
SELECT
patient_id, visit_date,
LAG(visit_date) OVER ( PARTITION BY patient_id ORDER BY visit_date) AS previous_visit_date
FROM appointments
),
visit_gaps AS (
SELECT
patient_id,
DATEDIFF(visit_date, previous_visit_date) AS days_between_visits
FROM patient_visits
WHERE previous_visit_date IS NOT NULL
)
SELECT
Patient_id,
ROUND(AVG(days_between_visits), 2) AS average_days_between_visits
FROM visit_gaps
GROUP BY Patient_id
HAVING ROUND(AVG(days_between_visits), 2) >0
ORDER BY ROUND(AVG(days_between_visits), 2) asc;
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# 7.  How does each department’s performance compare with the hospital average?
WITH doctor_visit_counts AS (
SELECT
d.department, d.doctor_id,
COUNT(a.visit_id) AS visit_count
FROM doctors d
JOIN appointments a ON d.doctor_id = a.doctor_id
GROUP BY
d.department, d.doctor_id
),
department_avg AS (
SELECT
department,
AVG(visit_count) AS department_avg_visits
FROM doctor_visit_counts
GROUP BY department
),
hospital_avg AS (
SELECT
AVG(visit_count) AS hospital_avg_visits
FROM doctor_visit_counts
)
SELECT
da.department,
da.department_avg_visits,
ha.hospital_avg_visits,
da.department_avg_visits 
FROM department_avg da
CROSS JOIN hospital_avg ha
ORDER BY da.department_avg_visits DESC;
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# 8. Which doctors consistently perform above average over time?
WITH monthly_doctor_visits AS (
SELECT
d.doctor_id, d.doctor_name,
DATE_FORMAT(a.visit_date, '%Y-%m') AS visit_month,
COUNT(a.visit_id) AS monthly_visits
FROM doctors d
JOIN appointments a
ON d.doctor_id = a.doctor_id
GROUP BY
d.doctor_id,
d.doctor_name,
DATE_FORMAT(a.visit_date, '%Y-%m')
),
Overall_avg as (
SELECT
doctor_id, doctor_name, visit_month, monthly_visits AS doctor_monthly_visits,
AVG(monthly_visits) OVER ( PARTITION BY doctor_id) AS doctor_overall_avg_visits
FROM monthly_doctor_visits
ORDER BY doctor_id, visit_month)
SELECT * FROM Overall_avg WHERE doctor_monthly_visits > doctor_overall_avg_visits;
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# 9. Which departments contribute the highest share of total revenue ?
WITH department_revenue AS (
SELECT
d.department,
SUM(a.consultation_fee + a.treatment_cost) AS department_total_revenue
FROM doctors d
JOIN appointments a
ON d.doctor_id = a.doctor_id
GROUP BY d.department
)
SELECT
department,
department_total_revenue,
ROUND(
(department_total_revenue /
SUM(department_total_revenue) OVER ()) * 100,2) AS revenue_contribution_percentage
FROM department_revenue
ORDER BY department_total_revenue DESC;
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# 10. Is hospital activity growing faster or slower than before?
WITH monthly_activity AS (
SELECT
DATE_FORMAT(visit_date, '%Y-%b') AS visit_month,
DATE_FORMAT(visit_date, '%Y-%m') AS sort_key,
COUNT(visit_id) AS total_visits
FROM appointments
GROUP BY
DATE_FORMAT(visit_date, '%Y-%b'),
DATE_FORMAT(visit_date, '%Y-%m')
),
growth_comparison AS (
SELECT
visit_month, sort_key, total_visits,
LAG(total_visits) OVER ( ORDER BY sort_key) AS previous_month_visits
FROM monthly_activity
)
SELECT
visit_month, total_visits, previous_month_visits,
ROUND(((total_visits - previous_month_visits) / previous_month_visits) * 100,2) AS growth_percentage
FROM growth_comparison
WHERE previous_month_visits IS NOT NULL
ORDER BY sort_key;
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# 11. Is patient workload concentrated among a small group of doctors?
WITH doctor_workload AS (
    SELECT
        d.doctor_id,
        d.doctor_name,
        COUNT(a.visit_id) AS total_visits
    FROM doctors d
    JOIN appointments a
        ON d.doctor_id = a.doctor_id
    GROUP BY
        d.doctor_id,
        d.doctor_name
),
workload_share AS (
SELECT
doctor_id, doctor_name total_visits,
SUM(total_visits) OVER () AS hospital_total_visits,
SUM(total_visits) OVER ( ORDER BY total_visits DESc ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS cumulative_visits
FROM doctor_workload
)
SELECT
doctor_id, doctor_name, total_visits,
ROUND((total_visits / hospital_total_visits) * 100, 2) AS individual_visit_share_pct,
ROUND((cumulative_visits / hospital_total_visits) * 100, 2) AS cumulative_visit_share_pct
FROM workload_share
ORDER BY total_visits DESC;
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# 12. How does the patient volume at the start compare with the most recent period?
WITH monthly_visits AS (
SELECT
DATE_FORMAT(visit_date, '%Y-%m') AS visit_month,
COUNT(visit_id) AS total_visits
FROM appointments
GROUP BY DATE_FORMAT(visit_date, '%Y-%m')
),
visit_comparison AS (
SELECT
visit_month, total_visits,
FIRST_VALUE(total_visits) OVER (ORDER BY visit_month) AS start_period_visits,
LAST_VALUE(total_visits) OVER (ORDER BY visit_month ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) AS latest_period_visits
FROM monthly_visits
)
SELECT distinct
start_period_visits, latest_period_visits,
latest_period_visits - start_period_visits AS visit_difference
FROM visit_comparison;
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# 13. How stable is revenue generation per doctor over time?
WITH monthly_doctor_revenue AS (
SELECT
d.doctor_id, d.doctor_name,
DATE_FORMAT(a.visit_date, '%Y-%m') AS visit_month,
SUM(a.consultation_fee + a.treatment_cost) AS monthly_revenue
FROM doctors d
JOIN appointments a ON d.doctor_id = a.doctor_id
GROUP BY
d.doctor_id, d.doctor_name, DATE_FORMAT(a.visit_date, '%Y-%m')
),
revenue_variation AS (
SELECT
doctor_id, doctor_name, visit_month, monthly_revenue,
AVG(monthly_revenue) OVER (PARTITION BY doctor_id) AS avg_monthly_revenue
FROM monthly_doctor_revenue
)
SELECT
doctor_id, doctor_name, visit_month, monthly_revenue, avg_monthly_revenue, monthly_revenue - avg_monthly_revenue AS deviation_from_average
FROM revenue_variation
ORDER BY doctor_id, visit_month;
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# 14. How can patients be divided into groups based on how often they visit?
WITH patient_visit_counts AS (
SELECT
patient_id,
COUNT(visit_id) AS total_visits
FROM appointments
GROUP BY patient_id
),
visit_frequency_groups AS (
SELECT
patient_id, total_visits,
NTILE(3) OVER ( ORDER BY total_visits) AS visit_group
FROM patient_visit_counts
)
SELECT
patient_id,
total_visits,
CASE
	WHEN visit_group = 1 THEN 'Low Frequency'
	WHEN visit_group = 2 THEN 'Medium Frequency'
	WHEN visit_group = 3 THEN 'High Frequency'
    END AS visit_frequency_segment
FROM visit_frequency_groups
ORDER BY total_visits desc;
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# 15. How have department rankings changed across different time periods?

WITH monthly_department_visits AS (
SELECT
d.department,
DATE_FORMAT(a.visit_date, '%Y-%m') AS visit_month,
COUNT(a.visit_id) AS total_visits
FROM doctors d
JOIN appointments a ON d.doctor_id = a.doctor_id
GROUP BY
d.department, DATE_FORMAT(a.visit_date, '%Y-%m')
),
department_ranks AS (
SELECT
department, visit_month, total_visits,
DENSE_RANK() OVER (PARTITION BY visit_month ORDER BY total_visits DESC) AS department_rank
FROM monthly_department_visits
)
SELECT
department, visit_month, total_visits, department_rank
FROM department_ranks
ORDER BY visit_month, department_rank;

--------------------------------------------------------------------------XXX---------------------------------------------------------------------------------------------------
